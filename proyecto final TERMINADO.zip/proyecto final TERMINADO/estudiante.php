<?php
$servername = "localhost";
$database = "u408629193_belmont";
$username = "u408629193_akali";
$password = "Manolo123ca*";

// Create connection
$conexion = mysqli_connect($servername, $username, $password, $database);

// Verifica la conexión
if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}
$id_docente 		= $_POST['input1'];
$nombre_docente 	= $_POST['input2'];
$apellido_docente	= $_POST['input3'];
$materia 			= $_POST['input4'];
$contrasena_docente = $_POST['input5'];


// El usuario ha rellenado ambos campos
$query = "SELECT id_docente FROM docente WHERE id_docente='".mysqli_real_escape_string($conexion,$_POST['input1'])."'";
$result = mysqli_query($conexion,$query);
if (mysqli_num_rows($result)>0)
{
    header('Location:usu_registrado.html');
	
}



$query = "INSERT INTO docente VALUES ('$id_docente', '$nombre_docente','$apellido_docente','$materia','$contrasena_docente')";
if (mysqli_query($conexion, $query)) {
    header('Location:emergente.html');
    exit;
} else {
    header('Location:usu_registrado.html');
    exit;
}

mysqli_close($conexion);
?>
<script>
    document.getElementById('enviar-estudiantes').addEventListener('click', function(event) {
    event.preventDefault();
    window.open('emergente.html', '_blank', 'width=400,height=400');
});
</script>
