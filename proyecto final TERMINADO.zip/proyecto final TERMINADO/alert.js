const uploadButton = document.getElementById('uploadButton');

uploadButton.addEventListener('click', (event) => {
  event.preventDefault();
  const confirmation = confirm("¿Estás seguro de cambiar esta contraseña?");
  if (confirmation) {
    alert("Contraseña restablecida")
      window.location.href= "login.html";
  } else {
    alert("Contraseña cancelada");
  }
});

