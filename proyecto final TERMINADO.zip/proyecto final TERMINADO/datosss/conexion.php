<!-- conexion.php -->
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_registro";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->exec("SET NAMES utf8");
} catch(PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>

<!-- procesar_registro.php -->
<?php
require_once 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_inst = trim($_POST['nombre_inst']);
    $email_inst = trim($_POST['email_inst']);
    $contraseña = password_hash($_POST['contraseña'], PASSWORD_DEFAULT);

    try {
        // Verificar si el email ya existe
        $stmt = $conn->prepare("SELECT * FROM crear_cuenta WHERE email_inst = ?");
        $stmt->execute([$email_inst]);
        
        if ($stmt->rowCount() > 0) {
            echo '<script>
                    alert("Este correo electrónico ya está registrado");
                    window.location.href = "registro.html";
                  </script>';
            exit();
        }

        // Insertar en la tabla crear_cuenta
        $sql = "INSERT INTO crear_cuenta (nombre_inst, email_inst, contraseña) 
                VALUES (:nombre_inst, :email_inst, :contraseña)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':nombre_inst', $nombre_inst);
        $stmt->bindParam(':email_inst', $email_inst);
        $stmt->bindParam(':contraseña', $contraseña);
        
        if ($stmt->execute()) {
            // Insertar en la tabla login
            $sql = "INSERT INTO login (email, contraseña) VALUES (:email, :contraseña)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':email', $email_inst);
            $stmt->bindParam(':contraseña', $contraseña);
            $stmt->execute();
            
            echo '<script>
                    alert("Registro exitoso. Por favor inicia sesión.");
                    window.location.href = "login.html";
                  </script>';
        }
    } catch(PDOException $e) {
        echo '<script>
                alert("Error en el registro: ' . $e->getMessage() . '");
                window.location.href = "registro.html";
              </script>';
    }
}
?>

<!-- procesar_login.php -->
<?php
session_start();
require_once 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $contraseña = $_POST['contraseña'];

    try {
        $sql = "SELECT cc.* FROM crear_cuenta cc 
                INNER JOIN login l ON cc.email_inst = l.email 
                WHERE cc.email_inst = :email";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($usuario && password_verify($contraseña, $usuario['contraseña'])) {
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['nombre_inst'] = $usuario['nombre_inst'];
            header("Location: bienvenida.php");
            exit();
        } else {
            echo '<script>
                    alert("Email o contraseña incorrectos");
                    window.location.href = "login.html";
                  </script>';
        }
    } catch(PDOException $e) {
        echo '<script>
                alert("Error: ' . $e->getMessage() . '");
                window.location.href = "login.html";
              </script>';
    }
}
?>

<!-- bienvenida.php -->
<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Bienvenida</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container-form">
        <div class="formulario">
            <h2 class="create-account">Bienvenido/a <?php echo htmlspecialchars($_SESSION['nombre_inst']); ?>!</h2>
            <div class="iconos">
                <div class="border-icon">
                    <i class="fas fa-user"></i>
                </div>
            </div>
            <button class="btn-pp" onclick="location.href='logout.php'">Cerrar sesión</button>
        </div>
    </div>
    <script src="https://kit.fontawesome.com/c15b744a04.js" crossorigin="anonymous"></script>
</body>
</html>

<!-- logout.php -->
<?php
session_start();
session_destroy();
header("Location: login.html");
?>