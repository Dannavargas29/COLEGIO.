const documentList = document.getElementById("documentList");

function uploadDocument() {
    const grado = document.getElementById("grado").value;
    const materia = document.getElementById("materia").value;
    const archivo = document.getElementById("archivo").files[0];

    if (!grado || !materia || !archivo) {
        alert("Por favor, completa todos los campos.");
        return;
    }

    // Crea un elemento de lista para el archivo subido
    const listItem = document.createElement("li");
    listItem.textContent = `${grado} - ${materia} - ${archivo.name}`;

    // Botón para eliminar el documento
    const deleteButton = document.createElement("button");
    deleteButton.textContent = "Eliminar";
    deleteButton.onclick = function() {
        documentList.removeChild(listItem);
    };

    listItem.appendChild(deleteButton);
    documentList.appendChild(listItem);

    // Limpia el formulario
    document.getElementById("documentForm").reset();
}
